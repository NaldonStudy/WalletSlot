package com.ssafy.b108.walletslot.backend.domain.account.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetPrimaryAccountResponseDto {

    // Field
    private boolean success;
    private String message;
    private AccountDto data;
}
