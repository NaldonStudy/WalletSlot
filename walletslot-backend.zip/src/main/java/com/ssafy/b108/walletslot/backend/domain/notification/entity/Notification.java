package com.ssafy.b108.walletslot.backend.domain.notification.entity;

public class Notification {
}
