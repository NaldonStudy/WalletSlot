package com.ssafy.b108.walletslot.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletslotBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
